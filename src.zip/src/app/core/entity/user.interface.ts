export interface User {
    userID?: string;
    name?: string;
    age?: string;
    password?: string;
    agencia?: string;
    conta?: string;
}