export class Labels {
    public static labelsPtBr = require('./labels_pt-br.json');

    public static getLabels() {
        return this.labelsPtBr;
    }
}